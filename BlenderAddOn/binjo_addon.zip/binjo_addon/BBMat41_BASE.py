import bpy
import os
import subprocess
from bpy.types import Operator
from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       FloatProperty,
                       FloatVectorProperty,
                       EnumProperty,
                       PointerProperty,
                       )

bl_info = {
    "name" : "BB Material Setup",
    "description" : "Adds a button to convert blender material setups into ones that export correctly",
    "author" : "jombo23",
    "version" : (3, 0, 0),
    "blender" : (3, 5, 0),
    "location" : "Node",
    "warning" : "",
    "support" : "COMMUNITY",
    "doc_url" : "",
    "category" : "3D View"
}

menu_keymap = None

def initialize_keymap():
    key_config = bpy.context.window_manager.keyconfigs.addon
    if key_config:
        key_map = key_config.keymaps.new(name='Node Editor', space_type='NODE_EDITOR')
        key_entry = key_map.keymap_items.new(SHADE_OT_demo.bl_idname,
                                                            type='Q',
                                                            value='PRESS',
        )
        menu_keymap = (key_map, key_entry)
            
def deinitialize_keymap():
    pass
            
def shader_menu_draw(self, context):
    self.layout.operator("shade.demo")
def shader_menutwo_draw(self, context):
    self.layout.operator("shade.go")
    

def shader_menuthree_draw(self, context):
    self.layout.operator("shade.alpha")

def shader_menufour_draw(self, context):
    self.layout.operator("shade.export")

def setVColor(Alpha):
    if bpy.context.scene.get('alpha') is None:
        bpy.context.scene['alpha'] = True
    for mesh in bpy.context.collection.objects:
        hasAlpha = False
        hasColor = False
        index = 0
        if mesh.type != "MESH":
            continue
        for att in mesh.data.color_attributes:
            if att.name in (["Attribute", "Col", "col"]):
                att.name = "Color"
            if att.name == "Alpha":
                hasAlpha = True
                if Alpha == True:
                    mesh.data.attributes.active_color_index = index
            if att.name == "Color":
                hasColor = True
                if Alpha == False:
                    mesh.data.attributes.active_color_index = index
            index+=1

        if hasColor is False:
            mesh.data.attributes.new(name='Color', domain='CORNER', type='BYTE_COLOR')        
        if hasAlpha is False:
            mesh.data.attributes.new(name='Alpha', domain='CORNER', type='BYTE_COLOR')   
                

        index = 0
            
        for att in mesh.data.color_attributes:
            if att.name == "Attribute":
                att.name = "Color"
            if att.name == "Alpha":
                hasAlpha = True
                if Alpha == True:
                    mesh.data.attributes.active_color_index = index
            if att.name == "Color":
                hasColor = True
                if Alpha == False:
                    mesh.data.attributes.active_color_index = index
            index+=1
    
def createAlphaNodes(Alpha):
    isInit = False
    if bpy.context.scene.get('alpha') is None:
        bpy.context.scene['alpha'] = Alpha

    for mat in bpy.data.materials:
        image = None
        if mat.use_nodes == True:
            for node in mat.node_tree.nodes:
                if node.type == "TEX_IMAGE":
                    image = node.image
                    break
            for remnode in mat.node_tree.nodes:
                        mat.node_tree.nodes.remove(remnode)
            if Alpha == True:
                mat.blend_method = "HASHED"
            else:
                mat.blend_method = "OPAQUE"
            if image is not None:
                if Alpha == True:
                    newImagenode = mat.node_tree.nodes.new("ShaderNodeTexImage")
                    newImagenode.image = image
                    newImagenode.location = (-600,0)
                    newMixnode = mat.node_tree.nodes.new("ShaderNodeMixRGB")
                    newMixnode.blend_type = "MULTIPLY"
                    newMixnode.location = (-300, 0)
                    newMixnode.inputs[0].default_value = 1.0

                    newMixnode2 = mat.node_tree.nodes.new("ShaderNodeMixRGB")
                    newMixnode2 = mat.node_tree.nodes.new("ShaderNodeMixRGB")
                    newMixnode2.blend_type = "MULTIPLY"
                    newMixnode2.location = (-300, -300)
                    newMixnode2.inputs[0].default_value = 1.0

                    newAttnode = mat.node_tree.nodes.new("ShaderNodeVertexColor")
                    newAttnode.location = (-600,-300)
                    newAttnode.layer_name = "Color"
                    newAlphaAttnode = mat.node_tree.nodes.new("ShaderNodeVertexColor")
                    newAlphaAttnode.layer_name = "Alpha"
                    newAttnode.location = (-600,-300)
                    newAlphaAttnode.location = (-600,-500)
                    newShadernode = mat.node_tree.nodes.new("ShaderNodeBsdfPrincipled")
                    
                    mat.node_tree.links.new(newMixnode2.inputs[1], newImagenode.outputs[1])
                    mat.node_tree.links.new(newMixnode2.inputs[2], newAlphaAttnode.outputs[0])
                    mat.node_tree.links.new(newShadernode.inputs[21], newMixnode2.outputs[0])
                    mat.node_tree.links.new(newMixnode.inputs[1], newImagenode.outputs[0])
                    mat.node_tree.links.new(newMixnode.inputs[2], newAttnode.outputs[0])
                    mat.node_tree.links.new(newShadernode.inputs[0], newMixnode.outputs[0])
                    outputnode = mat.node_tree.nodes.new("ShaderNodeOutputMaterial")
                    outputnode.location = (300,0)
                    outputnode.target = "EEVEE"
                    mat.node_tree.links.new(outputnode.inputs[0], newShadernode.outputs[0])

                newImagenode2 = mat.node_tree.nodes.new("ShaderNodeTexImage")
                newImagenode2.image = image
                newImagenode2.location = (-300,-1000)
                newShadernode2 = mat.node_tree.nodes.new("ShaderNodeBsdfPrincipled")
                newShadernode2.location = (0,-1000)
                mat.node_tree.links.new(newShadernode2.inputs[0], newImagenode2.outputs[0])
                outputnode2 = mat.node_tree.nodes.new("ShaderNodeOutputMaterial")
                outputnode2.location = (300,-1000)
                outputnode2.target = "ALL"
                mat.node_tree.links.new(outputnode2.inputs[0], newShadernode2.outputs[0])
            else:
                newAttnode = mat.node_tree.nodes.new("ShaderNodeVertexColor")
                newAttnode.layer_name = "Color"
                newAlphaAttnode = mat.node_tree.nodes.new("ShaderNodeVertexColor")
                newAlphaAttnode.layer_name = "Alpha"
                newAttnode.location = (-600,-300)
                newAlphaAttnode.location = (-600,-500)
                newShadernode = mat.node_tree.nodes.new("ShaderNodeBsdfPrincipled")
                mat.node_tree.links.new(newShadernode.inputs[0], newAttnode.outputs[0])
                mat.node_tree.links.new(newShadernode.inputs[21], newAlphaAttnode.outputs[0])
                outputnode = mat.node_tree.nodes.new("ShaderNodeOutputMaterial")
                outputnode.location = (300,0)
                outputnode.target = "EEVEE"
                mat.node_tree.links.new(outputnode.inputs[0], newShadernode.outputs[0])
                newShadernode2 = mat.node_tree.nodes.new("ShaderNodeBsdfPrincipled")
                newShadernode2.location = (0,-1000)
                outputnode2 = mat.node_tree.nodes.new("ShaderNodeOutputMaterial")
                outputnode2.location = (300,-1000)
                outputnode2.target = "ALL"
                mat.node_tree.links.new(outputnode2.inputs[0], newShadernode2.outputs[0])

class HelloWorldPanel(bpy.types.Panel):
    bl_idname = "OBJ_PT_N_MAT_SETUP"
    bl_label = "Material Setup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"
    bl_context = "objectmode"



    def draw(self, context):
        self.layout.label(text="Set-up Materials")
        scene = context.scene
        layout = self.layout
        col = layout.column(align=True)
        row = layout.row(align=True)
        split = layout.split(factor=0.2)
        row.prop(scene, "alpha")
       
        #row = split.row()
        row = layout.row(align=True)
        row.prop(scene, "exportPath")

class SHADE_OT_go(Operator):
    bl_idname = "shade.go"
    bl_label = "Set VColor Color"
    bl_description = "sets all active color attributes to color"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(self, context):
        return True

    def execute(self, context):
        setVColor(False)
        return {'FINISHED'}

def pathError(self, context):
    self.layout.label(text="Set an export directory in the path above")

class SHADE_OT_export(Operator):
    bl_idname = "shade.export"
    bl_label = "Export OBJs"
    bl_description = "exports objs and converts to geobj"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(self, context):
        return True

    def execute(self, context):
        if bpy.context.scene.get('exportPath') is None:
            bpy.context.scene['exportPath'] = "Set me"
        if bpy.context.scene.get('exportPath') == "Set me":
            bpy.context.window_manager.popup_menu(pathError, title="Error", icon='ERROR')
            return {'FINISHED'}
        setVColor(True)
        createAlphaNodes(False)
        bpy.ops.wm.obj_export(filepath=bpy.context.scene.get('exportPath') + bpy.path.basename(bpy.context.blend_data.filepath)[:-6] + ".obja", export_colors=True, export_triangulated_mesh=True, path_mode='COPY')
        setVColor(False)
        bpy.ops.wm.obj_export(filepath=bpy.context.scene.get('exportPath') + bpy.path.basename(bpy.context.blend_data.filepath)[:-6] + ".obj", export_colors=True, export_triangulated_mesh=True, path_mode='COPY')
        script_file = os.path.realpath(__file__)
        directory   = os.path.dirname(script_file)
        subprocess.run([directory + "\\obj2geobj.exe", bpy.context.scene.get('exportPath') + bpy.path.basename(bpy.context.blend_data.filepath)[:-6] + ".obj"], stdin=None, input=None, stdout=None, stderr=None, shell=False, timeout=None, check=False)
        os.remove(bpy.context.scene.get('exportPath') + bpy.path.basename(bpy.context.blend_data.filepath)[:-6] + ".obja")
        if bpy.context.scene.get('alpha') is not None:
            if bpy.context.scene.get('alpha') == True:
                createAlphaNodes(False)
            else:
                createAlphaNodes(True)
        else:
            createAlphaNodes(True)
        
        return {'FINISHED'}

class SHADE_OT_alpha(Operator):
    bl_idname = "shade.alpha"
    bl_label = "Set VColor Alpha"
    bl_description = "sets all active color attributes to alpha"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(self, context):
        return True

    def execute(self, context):
        setVColor(True)
        return {'FINISHED'}
class SHADE_OT_demo(Operator):
    bl_idname = "shade.demo"
    bl_label = "Set Materials Up"
    bl_description = "makes shit into bb materials"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(self, context):
        return True

    def execute(self, context):
        if bpy.context.scene.get('exportPath') is None:
            bpy.context.scene['exportPath'] = "Set me"

        if bpy.context.scene.get('alpha') is not None:
            if bpy.context.scene.get('alpha') == True:
                createAlphaNodes(False)
            else:
                createAlphaNodes(True)
        else:
            createAlphaNodes(True)



        
        return {'FINISHED'}
    

classes = [
    SHADE_OT_demo,
    SHADE_OT_go,
    SHADE_OT_alpha,
    SHADE_OT_export,
]

def register():
    for c in classes:
        bpy.utils.register_class(c)
    #initialize_keymap()
    #bpy.types.NODE_HT_header.append(shader_menu_draw)
    
    bpy.utils.register_class(HelloWorldPanel)
    bpy.types.OBJ_PT_N_MAT_SETUP.append(shader_menu_draw)
    bpy.types.OBJ_PT_N_MAT_SETUP.append(shader_menutwo_draw)
    bpy.types.OBJ_PT_N_MAT_SETUP.append(shader_menuthree_draw)
    bpy.types.OBJ_PT_N_MAT_SETUP.append(shader_menufour_draw)

    bpy.types.Scene.alpha = bpy.props.BoolProperty(
        name="View Export Config",
        description="Set up Materials as they would be for exporting",
        default = False)

    bpy.types.Scene.exportPath = bpy.props.StringProperty(
        name="Path",
        description="Check this before exporting",
        default = "Set me",
        subtype='DIR_PATH')
        
    #bpy.types.NODE_HT_header.append(HelloWorldPanel)
        
def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)
    #deinitialize_keymap()
    #bpy.types.NODE_HT_header.remove(shader_menu_draw)
    bpy.types.OBJ_PT_N_MAT_SETUP.remove(shader_menu_draw)
    bpy.types.OBJ_PT_N_MAT_SETUP.remove(shader_menutwo_draw)
    bpy.types.OBJ_PT_N_MAT_SETUP.remove(shader_menuthree_draw)
    bpy.types.OBJ_PT_N_MAT_SETUP.remove(shader_menufour_draw)
    #bpy.types.NODE_HT_header.remove(HelloWorldPanel)
    bpy.utils.unregister_class(HelloWorldPanel)
    del bpy.types.Scene.alpha
    del bpy.types.Scene.exportPath
if __name__ == '__main__':
    register()